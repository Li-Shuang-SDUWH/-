#ifndef __TEMP_H_
#define __TEMP_H_

#include<reg51.h>

#ifndef uchar
#define uchar unsigned char
#endif

#ifndef uint
#define uint unsigned int
#endif

sbit desport=P1^6;

void delay1ms(uint x);
uchar dsinit();
void dswrite(uchar dat);
uchar dsread();
void dschangetempcom();
void dsreadtempcom();
uchar dsreadtemp();
#endif